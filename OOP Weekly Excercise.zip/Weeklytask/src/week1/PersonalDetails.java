package week1;
public class PersonalDetails {
	public static void main(String[] args) {
		System.out.println("Name: Astha Phagami\nAddress: Nakhipot, Lalitpur\nAge: 20\nPhone-no: 9841724724");
	}

}
