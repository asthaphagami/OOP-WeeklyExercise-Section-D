package week1;

public class Test { 
	//---------------------------------------------------- 
	// Prints a statement. 
	//---------------------------------------------------- 
	public static void main (String[] args) { 
		System.out.println ("An Emergency Broadcast"); 
	} 
}
