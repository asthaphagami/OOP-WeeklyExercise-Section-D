package week1;
public class Diamondshape {
	public static void main(String[] args) {
		System.out.println("   *\n  ***\n *****\n*******\n *****\n  ***\n   *");
		
	}

}
