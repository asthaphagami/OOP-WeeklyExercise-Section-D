package week7;
class PlayerStats {
    protected String playerName; protected int playerNumber; protected int gamesPlayed;
    public PlayerStats(String playerName, int playerNumber) {
        this.playerName = playerName; this.playerNumber = playerNumber;
        this.gamesPlayed = 0;
    }
    public void playGame() {
        gamesPlayed++;
    }
    public void displayStats() {
        System.out.println("Player: " + playerName);
        System.out.println("Player Number: " + playerNumber);
        System.out.println("Games Played: " + gamesPlayed);
    }
}
class FootballStats extends PlayerStats {
    private int goalsScored;
    public FootballStats(String playerName, int playerNumber) {
        super(playerName, playerNumber);
        this.goalsScored = 0;
    }
    public void scoreGoal() {
        goalsScored++;
    }
    public void displayStats() {
        super.displayStats();
        System.out.println("Goals Scored: " + goalsScored);
    }
}
class CricketStats extends PlayerStats {
    private int runsScored;
   public CricketStats(String playerName, int playerNumber) {
        super(playerName, playerNumber);
        this.runsScored = 0;
    }
    public void scoreRuns(int runs) {
        runsScored += runs;
    }
    public void displayStats() {
    	super.displayStats();
        System.out.println("Runs Scored: " + runsScored);
    }
}
public class PlayerStatistics {
	public static void main(String[] args) {
		 FootballStats footballPlayer = new FootballStats("Siwan khadka", 5);
	        footballPlayer.playGame();
	        footballPlayer.scoreGoal();
	        footballPlayer.displayStats();
	       
	        CricketStats cricketPlayer = new CricketStats("Sushan Khadka", 6);
	        cricketPlayer.playGame();
	        cricketPlayer.scoreRuns(50);
	        cricketPlayer.displayStats();
	}
}
