package week7;
class Employee {
    protected int emp_Id; protected String name;
    public Employee(int empId, String name) {this.emp_Id = empId; this.name = name;}
    public void performDuty() {
        System.out.println("Employee " + emp_Id + " is performing their duty.");}
}
class Doctor extends Employee {
    private String specialization;
    public Doctor(int empId, String name, String specialization) {
        super(empId, name); this.specialization = specialization;}
    public void performDuty() {
        System.out.println(emp_Id + "  "+ name +", specializes in " + specialization + ".");}
}
class Nurse extends Employee {
    public Nurse(int empId, String name) {super(empId, name);}
    public void performDuty() {
        System.out.println( emp_Id + " " + name + ", is taking care of patients.");}
}
class Receptionist extends Employee {
    public Receptionist(int empId, String name) {super(empId, name);}
    public void performDuty() {
        System.out.println("Receptionist " + emp_Id + " " + name + ", is managing the front desk.");}
}
class Cleaner extends Employee {
    public Cleaner(int empId, String name) { super(empId, name); }
    public void performDuty() { System.out.println(name + " is cleaning the hospital."); }
}
public class Hospital {
    public static void main(String[] args) {
        Doctor doctor = new Doctor(101, "Dr. Samir", "Cardiology");
        Nurse nurse = new Nurse(201, "Nurse Bimla");
        Receptionist receptionist = new Receptionist(301, "Ashmita");
        Cleaner cleaner = new Cleaner(401, "Maya");
        doctor.performDuty();
        nurse.performDuty();
        receptionist.performDuty();
        cleaner.performDuty();
    }
}
