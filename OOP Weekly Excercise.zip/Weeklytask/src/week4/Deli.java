package week4;
import java.text.DecimalFormat;
import java.text.NumberFormat;
import java.util.Scanner;
public class Deli {
	public static void main(String[] args) {
		final double OUNCE_PER_POUND = 16.0;
		double pricePerPound,wegihtOunce,weight,totalPrice;
		Scanner Scanner = new Scanner(System.in);
		NumberFormat money = NumberFormat.getCurrencyInstance();
		DecimalFormat fmt = new DecimalFormat("0.00");
		
		System.out.println("Welcome to the CS Deli!\n");
		System.out.println("Enter the price per pound of your item: ");
		pricePerPound = Scanner.nextDouble();
		System.out.print("Enter the weight(ounce): ");
		wegihtOunce = Scanner.nextDouble();
		
		weight = wegihtOunce/OUNCE_PER_POUND;
		totalPrice=pricePerPound*weight;
		
		System.out.println("\n******** CS Deli ********"); 
		System.out.println("Unit Price: " + money.format(pricePerPound) + "pound");
		System.out.println("Weight: " + fmt.format(weight) + "pound");
		System.out.println("Total: " + money.format(totalPrice));
	}

}
