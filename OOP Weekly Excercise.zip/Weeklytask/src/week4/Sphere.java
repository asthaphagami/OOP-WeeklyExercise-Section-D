package week4;
import java.util.Scanner;
public class Sphere {
	public static void main(String[] args) {
		Scanner scanner = new Scanner (System.in);
		System.out.println("Enter the radius of the sphere:");
		double radius = scanner.nextDouble();
		System.out.println("Volume:" +(4.0 / 3 * Math.PI * radius*radius*radius));
		System.out.println("SurfaceArea:" +(4 * Math.PI * radius*radius*radius));
	}
}
