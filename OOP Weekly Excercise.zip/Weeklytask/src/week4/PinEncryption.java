package week4;
import java.util.Random;
import java.util.Scanner;
public class PinEncryption {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        Random random = new Random();
        System.out.print("Enter a 4-digit PIN: ");
        String pinHex = Integer.toHexString(scanner.nextInt());
        String encryptedPin = Integer.toHexString(random.nextInt(64536) + 1000) +
                              pinHex + Integer.toHexString(random.nextInt(64536) + 1000);
        System.out.println("Encrypted PIN: " + encryptedPin);
        scanner.close();
    }
}
