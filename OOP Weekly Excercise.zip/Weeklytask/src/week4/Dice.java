package week4;
import java.util.Random;
import java.util.Scanner;
public class Dice {
	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		Random random = new Random();
		System.out.println("How may sides does dice 1 have? ");
		int side1 =scanner.nextInt();
		System.out.println("How many sides does dice 2 have? ");
		int side2 =scanner.nextInt();
		int total1 = 0, total2=0;
		 for (int roll=1; roll <=3; roll++) {
			 int die1 = random.nextInt(side1) + 1;
			 int die2 = random.nextInt(side2) + 1;
			 total1 += die1; total2 += die2;
			 System.out.println("Die 1 roll " + roll + " = "+die1);
			 System.out.println("Die 2 roll " + roll + " = "+die2); 
		 }
		 System.out.println("Die 1 rolled a total of " + total1 +" and rolled "+(total1 / 3.0)+" on average.");
		 System.out.println("Die 2 rolled a total of " + total2 +" and rolled "+(total2 / 3.0)+" on average.");
	}

}
