package week2;
import java.util.Scanner;
public class Fraction {
    public static void main(String[] args) {
        Scanner scan = new Scanner(System.in);
        System.out.print("Enter numerator and denominator: ");
        double decimal = (double) scan.nextInt() / scan.nextInt();
        System.out.println("The decimal equivalent is " + decimal);
    }
}
