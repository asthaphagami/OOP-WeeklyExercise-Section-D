package week2;

public class StudentGrade {
    public static void main(String[] args) {
        System.out.println("///////////////////\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\n==          Student Points          ==\n\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\///////////////////\n");
        String[] names = {"Astha", "Ram", "Charlie", "Smriti", "Shyam"};
        int[] lab = {45, 38, 42, 47, 40};
        int[] bonus = {5, 7, 8, 6, 9};
        System.out.println("Name\t\tLab\tBonus\tTotal\n----\t\t---\t-----\t-----");
        for (int i = 0; i < names.length; i++) {
            System.out.println(names[i] + "\t\t" + lab[i] + "\t" + bonus[i] + "\t" + (lab[i] + bonus[i]));
        }
    }
}
