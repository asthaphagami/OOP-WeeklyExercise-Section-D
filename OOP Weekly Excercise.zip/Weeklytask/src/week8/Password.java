package week8;
interface Encryptable {
    String encrypt(String text);
    String decrypt(String cipherText);
}

class Reverser implements Encryptable {
    private String reverse(String s) {
        return new StringBuilder(s).reverse().toString();
    }

    public String encrypt(String text) {
        return reverse(text);
    }

    public String decrypt(String cipherText) {
        return reverse(cipherText);
    }
}
public class Password {
    public static void main(String[] args) {
        Encryptable reverser = new Reverser();
        String secret = "Hello world!";
        String secretCipher = reverser.encrypt(secret);
        System.out.println("Secret Cipher: " + secretCipher);
        System.out.println("Decrypted Secret: " + reverser.decrypt(secretCipher));
        String password = "Openmind";
        String passwordCipher = reverser.encrypt(password);
        System.out.println("Password Cipher: " + passwordCipher);
        System.out.println("Decrypted Password: " + reverser.decrypt(passwordCipher));
    }
}
