package week8;
import java.util.*;
class Employee {
    String name, role;
    Employee(String name, String role) {
        this.name = name;
        this.role = role;
    }
    void takeVacation() {
        System.out.println(name + " is taking vacation.");
    }
}
class Firm {
    List<Employee> employees = new ArrayList<>();
    void addEmployee(Employee e) {
        employees.add(e);
    }
    void showEmployees() {
        employees.forEach(e -> System.out.println(e.name + " - " + e.role));
    }
    void giveVacationOptions() {
        for (var e : employees) {
            System.out.println("Vacation options for " + e.name + " (" + e.role + "):");
            int weeks = switch (e.role) {
                case "Manager" -> 1;
                case "Developer" -> 2;
                default -> 3;
            };
            System.out.println("- Paid vacation for " + weeks + " weeks.");
        }
    }
}
public class FirmVacation {
    public static void main(String[] args) {
        var firm = new Firm();
        firm.addEmployee(new Employee("Jash", "Manager"));
        firm.addEmployee(new Employee("Ashish", "Developer"));
        firm.addEmployee(new Employee("Bhim", "Intern"));

        System.out.println("Employees:");
        firm.showEmployees();

        System.out.println("\nVacation Options:");
        firm.giveVacationOptions();
    }
}
