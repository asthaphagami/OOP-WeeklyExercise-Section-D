package week9;
class SavingsAccount {
    private int accountNumber;
    private String customerName;
    private double balance;
    public SavingsAccount(String customerName, int accountNumber, double initialbalance) {
        this.customerName = customerName; this.balance = initialbalance;
        this.accountNumber = accountNumber;
    }
    public void deposit(double amount) {
        if (amount <= 0) {
            System.out.println("Error: Invalid deposit amount.");
            return;
        }balance += amount;
        System.out.println(amount + " deposited successfully. New balance: " + balance);}
    public void withdraw(double amount) {
        if (amount <= 0 || amount > balance) {
            System.out.println("Error: Invalid withdrawal amount.");
            return;
        }balance -= amount;
        System.out.println(amount + " withdrawn successfully. New balance: " + balance);}
    public void addInterest() {
        double interest = balance * 0.03;
        balance += interest;
        System.out.println("Interest added. New balance: " + balance);
    }
    public void displayAccountInfo() {
        System.out.println("Account Number: " + accountNumber);
        System.out.println("Customer Name: " + customerName);
        System.out.println("Balance: " + balance);
    }
}
public class LLBankAccount {
	public static void main(String[] args) {
		SavingsAccount[] accounts = new SavingsAccount[30];
		int accountCount = 3;
        accounts[0] = new SavingsAccount("Ama", 1001, 1000);
        accounts[1] = new SavingsAccount("Budy", 1002, 2000);
        accounts[2] = new SavingsAccount("Charls", 1003, 3000);
        accounts[0].deposit(500);
        accounts[1].withdraw(400);
        accounts[2].withdraw(3000);
        for (int i = 0; i < accountCount; i++) {
            accounts[i].addInterest();
            accounts[i].displayAccountInfo();
        }}}
