package week9;
import java.util.ArrayList;
import java.util.Collections;
public class QuizTime {
    public static void main(String[] args) {
        Quiz obj = new Quiz();
        String[][] questions = {
            {"What is the capital of France?", "Paris"},{"What is 2 + 2?", "4"},
            {"Who wrote 'Hamlet'?", "Shakespeare"},
            {"Which planet is known as the Red Planet?", "Mars"},
            {"What gas do plants absorb?", "Carbon dioxide"},
            {"What is the largest ocean?", "Pacific"},{"In which year did WW2 end?", "1945"},
            {"What is the hardest natural substance?", "Diamond"},
            {"Which part of the plant does photosynthesis?", "Leaf"},
            {"Who painted the Mona Lisa?", "Leonardo da Vinci"},
            {"Which is the smallest continent?", "Australia"},
            {"How many legs does a spider have?", "8"},
            {"What is the chemical symbol for water?", "H2O"},
            {"Which planet is closest to the Sun?", "Mercury"},
            {"What do bees use to make honey?", "Nectar"},
            {"What is the longest river?", "Nile"},
            {"Which language has most native speakers?", "Mandarin"},
            {"Who discovered penicillin?", "Alexander Fleming"},
            {"Which animal is the king of the jungle?", "Lion"},
            {"What is the square root of 64?", "8"},
            {"How many continents are there?", "7"},
            {"Which organ purifies blood?", "Kidney"},
            {"Boiling point of water in Celsius?", "100"},
            {"Main ingredient in bread?", "Flour"},
            {"Which instrument has keys and strings?", "Piano"},
        };
        for (String[] q : questions) {
            obj.addQuiz(q[0], q[1]);
        }
        int numQuestions = obj.que.size();
        ArrayList<Integer> indices = new ArrayList<>();
        for (int i = 0; i < numQuestions; i++) {
            indices.add(i);
        }
        Collections.shuffle(indices);
        for (int i : indices) {
            obj.showQuestion(i);
            boolean continueQuiz = obj.askAnswer(i);
            if (!continueQuiz) {
                break;
            } }
        obj.showResult();
    }}
