package week9;
import java.util.ArrayList;
import java.util.Scanner;
public class Quiz {
    protected int marks;
    protected ArrayList<String> que;
    protected ArrayList<String> ans;
    public Quiz() {
        que = new ArrayList<>();
        ans = new ArrayList<>();
        marks = 0;
    }
    public void addQuiz(String question, String answer) {
        que.add(question);
        ans.add(answer);
    }
    public void showQuestion(int index) {
        System.out.println("\nQuestion " + (index + 1) + ": " + que.get(index));
    }
    public boolean askAnswer(int index) {
        Scanner sc = new Scanner(System.in);
        System.out.print("Your answer (or type 'q' to quit): ");
        String userAns = sc.nextLine().trim();
        if (userAns.equalsIgnoreCase("q")) {
            System.out.println("Exiting quiz early...");
            return false;
        }
        if (userAns.equalsIgnoreCase(ans.get(index).trim())) {
            System.out.println("Correct!");
            marks++;
        } else {
            System.out.println("Incorrect! Correct answer: " + ans.get(index));
        }
        return true;
    }
    public void showResult() {
        System.out.println("\nQuiz completed!");
        System.out.println("You scored: " + marks + " out of " + que.size());
    }
}