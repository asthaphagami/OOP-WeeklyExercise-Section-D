package week9;
import java.util.Scanner;
public class Histogram {
	public static void main(String[] args) {
        int[] frequency = new int[10];
        Scanner scanner = new Scanner(System.in);
        System.out.println("Enter integers between 1 and 100 (enter 0 to finish):");
        int value = scanner.nextInt();
        while (value != 0) {
            int rangeIndex = (value - 1) / 10;
            frequency[rangeIndex]++;
            value = scanner.nextInt();
        }
        System.out.println("Histogram:");
        for (int i = 0; i < frequency.length; i++) {
            int lowerBound = i * 10 + 1;
            int upperBound = (i + 1) * 10;
            System.out.print(lowerBound + " - " + upperBound + "\t| ");
            for (int j = 0; j < frequency[i]; j++) {
                System.out.print("*");
            }
            System.out.println();
        }
    }
}
