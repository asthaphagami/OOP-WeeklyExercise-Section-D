package week9;
import java.util.Scanner;
class Person {
    private String firstName;
    private String lastName;
    private String postalCode;

    public Person(String firstName, String lastName, String postalCode) {
        this.firstName = firstName;
        this.lastName = lastName;
        this.postalCode = postalCode;
    }

    @Override
    public String toString() {
        return firstName + " " + lastName + ", Postal Code: " + postalCode;
    }
}
public class PostalCode {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        Person[] people = new Person[25];
        int count = 0;
        System.out.println("Enter name and postal codes (type 'done' to finish):");
        while (count < 25) {
            String input = scanner.nextLine().trim();
            if (input.equalsIgnoreCase("done")) break;
            String[] parts = input.split("\\s+");
            if (parts.length == 3) {
                people[count++] = new Person(parts[0], parts[1], parts[2]);
            } else {
                System.out.println("Invalid input. Please enter: first name, last name, and postal code.");
            }
        }
        System.out.println("\nList of individuals:");
        for (int i = 0; i < count; i++) {
            System.out.println((i + 1) + ". " + people[i]);
        }
        scanner.close();
    }
}