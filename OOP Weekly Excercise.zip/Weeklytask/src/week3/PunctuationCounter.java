package week3;
import java.util.HashMap;
import java.util.Map;
public class PunctuationCounter {
	public static void main(String[] args) {
		String txt = "Mary had a little lamb, her fleece was as white as snow, "
				     +"and everywhere Mary went, the lamb was sure to go.\n-that was a nice poem-\n the end.";
	    Map<Character, Integer> counts = new HashMap<>();
	    txt.chars()
	       .filter(c ->".,!?-".indexOf(c) >= 0)
	       .forEach(c -> counts.put((char) c, counts.getOrDefault((char)c,0)+1));
	    counts.forEach((symbol, count)->System.out.println(symbol + ":" + count)); 
	}

}
