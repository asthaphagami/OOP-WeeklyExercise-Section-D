package week5;
class Bulb {
	private boolean is_on;
	public Bulb() {
		this.is_on = false;
	}
	public void turnON() {
		is_on = true;
		System.out.println("Bulb is on now.");
	}
	public void turnOFF() {
		is_on = false;
		System.out.println("Bulb is off now.");
	}
	@Override
	public String toString() {
		return is_on ? "Bulb is on.":"Bulb is off";
	}
}
public class Light {
	public static void main(String[] args) {
		Bulb b1 = new Bulb();
		Bulb b2 = new Bulb();
		b1.turnON();
		b2.turnON();
		System.out.println("Bulb 1:" + b1);
		System.out.println("Bulb 2:" + b2);
		b2.turnOFF();
		System.out.println("After turning off Bulb 2:" + b2);
	}
}
