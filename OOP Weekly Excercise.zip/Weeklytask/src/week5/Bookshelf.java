package week5;
class Book {
    private String title, author, publisher;
    private int copyrightDate;
    public Book(String title, String author, String publisher, int copyrightDate) {
        this.title = title;
        this.author = author;
        this.publisher = publisher;
        this.copyrightDate = copyrightDate;
    }
    public String getTitle() { return title; }
    public void setTitle(String title) { this.title = title; }
    public String getAuthor() { return author; }
    public void setAuthor(String author) { this.author = author; }
    public String getPublisher() { return publisher; }
    public void setPublisher(String publisher) { this.publisher = publisher; }
    public int getCopyrightDate() { return copyrightDate; }
    public void setCopyrightDate(int copyrightDate) { this.copyrightDate = copyrightDate; }
    public String toString() {
        return String.format("Book Details:\nTitle: %s\nAuthor: %s\nPublisher: %s\nCopyright Date: %d",
                              title, author, publisher, copyrightDate);
    }
}

public class Bookshelf {
    public static void main(String[] args) {
        Book book1 = new Book("To Kill a Mockingbird", "Harper Lee", "HarperCollins", 1960);
        Book book2 = new Book("1984", "George Orwell", "Secker & Warburg", 1949);
        System.out.println("Book 1:\n" + book1 + "\n");
        System.out.println("Book 2:\n" + book2 + "\n");
        book1.setPublisher("Penguin Books");
        System.out.println("After updating publisher of Book 1:\n" + book1);
    }
}
