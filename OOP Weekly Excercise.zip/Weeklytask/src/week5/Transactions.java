package week5;
class Account {
	private String name; int Accountno; double balance;
	public Account(String name, int accountno, double initialbalance) {
		this.name = name; this.Accountno=accountno; this.balance=initialbalance;
	}
	public Account(String name, int Accountno) {
		this(name, Accountno, 0.0);}
	public void deposit(double amount) {
		balance+=amount;}
	public void withdraw(double amount) {
		if(balance>=amount) {
			balance-=amount;
		}
	}
	public String toString() {
		return "Name:"+name+", Account.NO:"+Accountno+", Balance:"+balance;
    }
}
public class Transactions {
	public static void main(String[] args) {
		Account a1 = new Account("Honey Singh", 123455, 100.0);
		Account a2 = new Account("Arjit Rai", 123456);
		a1.deposit(50);
		a2.deposit(40);
		
		a1.withdraw(20);
		a2.withdraw(10);
		System.out.println(a1);
		System.out.println(a2);
	}
}
