package week5;
import java.util.Random;
public class Cards {
    private String suit;
    private String faceValue;
    public Cards(String suit, String faceValue) {
        this.suit = suit;
        this.faceValue = faceValue;
    }
    public String getSuit() {
        return suit;
    }
    public String getFaceValue() {
        return faceValue;
    }
    public String toString() {
        return faceValue + " of " + suit;
    }
    public static void main(String[] args) {
        String[] suits = {"Hearts", "Diamonds", "Clubs", "Spades"};
        String[] faceValues = {"A", "2", "3", "4", "5", "6", "7", "8", "9", "10", "J", "Q", "K"};
        Random random = new Random();
        System.out.println("Dealing five random cards:");
        for (int i = 0; i < 5; i++) {
            int suitIndex = random.nextInt(suits.length);
            int valueIndex = random.nextInt(faceValues.length);
            Cards card = new Cards(suits[suitIndex], faceValues[valueIndex]);
            System.out.println(card);
    }
    }
}
