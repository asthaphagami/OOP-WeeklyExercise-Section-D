package week5;
class Sphere {
    private double diameter; 
    public Sphere(double diameter) {
        this.diameter = diameter;
    }
    public double getDiameter() {
        return diameter;
    }
    public void setDiameter(double diameter) {
        this.diameter = diameter;
    }
    public double getVolume() { return (4.0 / 3) * Math.PI * Math.pow(diameter / 2, 3); }
    public double getSurfaceArea() { return 4 * Math.PI * Math.pow(diameter / 2, 2); }
    @Override
    public String toString() {
        return "Sphere with diameter: " + diameter;
    }
}
public class Multisphere {
    public static void main(String[] args) {
        Sphere sphere1 = new Sphere(10.0);
        Sphere sphere2 = new Sphere(15.0);
        sphere2.setDiameter(20.0);
        System.out.println(sphere1);
        System.out.println("Volume: " + sphere1.getVolume());
        System.out.println("Surface Area: " + sphere1.getSurfaceArea());
        System.out.println("\nUpdate Data:" + sphere2);
        System.out.println("Volume: " + sphere2.getVolume());
        System.out.println("Surface Area: " + sphere2.getSurfaceArea());
    }
}